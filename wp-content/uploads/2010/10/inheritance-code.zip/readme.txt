To compile, install flex then, run this command:

mxmlc RightApp.as

or

mxmlc WrongApp.as